---
name: voicemode
description: Manage VoiceMode TTS system messages and audio soundfonts. Use when creating or managing text-to-speech audio files for system messages, notifications, or voice prompts. Supports generating TTS audio with Kokoro or OpenAI voices and organizing soundfonts.
---

# VoiceMode System Messages

## Overview

Manage VoiceMode's text-to-speech system messages and soundfont audio files using the VoiceMode CLI. Generate TTS audio files for system messages, notifications, and voice prompts, then organize them in the soundfonts directory for use in VoiceMode sessions.

## Core Capabilities

### 1. Generate TTS System Messages

Create text-to-speech audio files for system messages using VoiceMode's TTS providers.

**Basic usage:**
```bash
# Generate TTS with default voice (af_sky if Kokoro available)
VOICEMODE_SAVE_AUDIO=true voicemode converse \
  --message "Task completed successfully" \
  --no-wait

# Use specific voice
VOICEMODE_SAVE_AUDIO=true voicemode converse \
  --message "Error: Connection timeout" \
  --voice af_sky \
  --no-wait

# Use OpenAI voice
VOICEMODE_SAVE_AUDIO=true voicemode converse \
  --message "Welcome to VoiceMode" \
  --voice nova \
  --tts-provider openai \
  --no-wait
```

**The generated audio files are saved to:**
- `~/.voicemode/audio/YYYY/MM/` (organized by date)
- Files are named with timestamps: `tts_YYYYMMDD_HHMMSS_XXXXX.wav`

### 2. Organize Soundfont Audio Files

Move generated TTS files to the soundfonts directory for easy access and organization.

**Soundfont directory structure:**
```
~/.voicemode/soundfonts/
├── system-messages/          # System notification messages
│   ├── task_complete.wav
│   ├── error_occurred.wav
│   └── welcome.wav
├── confirmations/            # User confirmations
│   ├── yes.wav
│   └── no.wav
└── alerts/                   # Alert sounds
    ├── warning.wav
    └── critical.wav
```

**Move files to soundfonts:**
```bash
# Find the most recent TTS file
LATEST_TTS=$(ls -t ~/.voicemode/audio/*/*/tts_*.wav | head -1)

# Move to system messages with descriptive name
mv "$LATEST_TTS" ~/.voicemode/soundfonts/system-messages/task_complete.wav
```

### 3. Available TTS Voices

**Kokoro Voices (Local TTS - Recommended):**
- `af_sky` - Natural female voice (default)
- `af_sarah` - Alternative female voice
- `am_adam` - Natural male voice
- `af_nicole` - Additional female option
- `am_michael` - Additional male option

**OpenAI Voices (Cloud TTS):**
- `alloy` - Balanced, neutral voice
- `nova` - Warm, expressive female voice
- `shimmer` - Bright, energetic female voice
- `fable` - Calm, storytelling voice
- `echo` - Clear, professional voice
- `onyx` - Deep, authoritative male voice

### 4. Naming Conventions

When saving TTS system messages to the soundfonts directory, use descriptive names that reflect the message content:

**Good naming examples:**
- `task_complete.wav` - "Task completed successfully"
- `error_occurred.wav` - "Error occurred"
- `processing.wav` - "Processing your request"
- `welcome.wav` - "Welcome to VoiceMode"
- `goodbye.wav` - "Goodbye"

**File naming pattern:**
- Use lowercase with underscores
- Be descriptive but concise
- Use `.wav` extension (VoiceMode default format)
- Avoid timestamps or version numbers (overwrite for updates)

## Workflow: Creating a System Message

Follow this workflow when users request a new system message:

1. **Generate the TTS audio:**
   ```bash
   VOICEMODE_SAVE_AUDIO=true voicemode converse \
     --message "Your message here" \
     --voice af_sky \
     --no-wait
   ```

2. **Find the generated file:**
   ```bash
   ls -t ~/.voicemode/audio/*/*/tts_*.wav | head -1
   ```

3. **Move to soundfonts with descriptive name:**
   ```bash
   LATEST_TTS=$(ls -t ~/.voicemode/audio/*/*/tts_*.wav | head -1)
   mkdir -p ~/.voicemode/soundfonts/system-messages
   mv "$LATEST_TTS" ~/.voicemode/soundfonts/system-messages/descriptive_name.wav
   ```

4. **Verify the file:**
   ```bash
   ls -lh ~/.voicemode/soundfonts/system-messages/descriptive_name.wav
   ```

## Common Tasks

### Create Multiple System Messages

When creating multiple messages in a session:

```bash
# Enable audio saving for the entire session
export VOICEMODE_SAVE_AUDIO=true

# Generate messages
voicemode converse --message "Task started" --no-wait
voicemode converse --message "Task in progress" --no-wait
voicemode converse --message "Task completed" --no-wait

# Review generated files
ls -lt ~/.voicemode/audio/*/*/tts_*.wav | head -3

# Move to soundfonts
mv ~/.voicemode/audio/*/*/tts_*1.wav ~/.voicemode/soundfonts/system-messages/task_started.wav
mv ~/.voicemode/audio/*/*/tts_*2.wav ~/.voicemode/soundfonts/system-messages/task_progress.wav
mv ~/.voicemode/audio/*/*/tts_*3.wav ~/.voicemode/soundfonts/system-messages/task_complete.wav
```

### Test Different Voices

Help users choose the right voice by generating samples:

```bash
export VOICEMODE_SAVE_AUDIO=true

# Try Kokoro voices
voicemode converse --message "Hello, this is af sky" --voice af_sky --no-wait
voicemode converse --message "Hello, this is af sarah" --voice af_sarah --no-wait
voicemode converse --message "Hello, this is am adam" --voice am_adam --no-wait

# Try OpenAI voices
voicemode converse --message "Hello, this is nova" --voice nova --tts-provider openai --no-wait
voicemode converse --message "Hello, this is shimmer" --voice shimmer --tts-provider openai --no-wait
```

### Update Existing System Message

Replace an existing soundfont file:

```bash
# Generate new version
VOICEMODE_SAVE_AUDIO=true voicemode converse \
  --message "Updated message text" \
  --voice af_sky \
  --no-wait

# Overwrite existing file
LATEST_TTS=$(ls -t ~/.voicemode/audio/*/*/tts_*.wav | head -1)
mv -f "$LATEST_TTS" ~/.voicemode/soundfonts/system-messages/existing_name.wav
```

## Important Notes

- **Default voice:** When `--voice` is not specified and Kokoro is available, VoiceMode defaults to `af_sky`
- **Audio saving:** Audio files are only saved when `VOICEMODE_SAVE_AUDIO=true` is set
- **No-wait mode:** Using `--no-wait` prevents VoiceMode from listening for a response, making it ideal for TTS-only generation
- **Headless systems:** VoiceMode converse works on servers without audio playback devices; it will log a warning but continue to generate and save audio files
- **File formats:** VoiceMode defaults to WAV format for maximum compatibility
- **Directory creation:** Always use `mkdir -p` to ensure soundfont subdirectories exist before moving files

## References

For detailed VoiceMode documentation, refer to:

- `references/cli-reference.md` - Complete CLI command reference
- `references/voice-selection.md` - Guide to selecting and configuring TTS voices
- `references/configuration.md` - VoiceMode configuration options

## Best Practices

1. **Voice consistency:** Use the same voice for all system messages in a project for consistency
2. **Test before deploying:** Always test system messages with `--no-wait` before integrating
3. **Organize by category:** Use subdirectories under `soundfonts/` to organize different message types
4. **Keep messages concise:** Shorter messages (1-2 sentences) work best for system notifications
5. **Document your soundfonts:** Maintain a README in your soundfonts directory listing all messages
