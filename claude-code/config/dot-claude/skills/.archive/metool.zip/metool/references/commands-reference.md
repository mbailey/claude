# Metool Commands Reference

Quick reference for all metool commands.

## Core Commands

### mt cd
Change to metool root or specified target

```bash
mt cd                    # Go to metool root
mt cd package-name       # Go to package directory
mt cd function-name      # Go to function's package directory
```

### mt components
List all package components (bin, shell, config, etc.)

```bash
mt components            # List all components from all packages
```

### mt deps
Check metool dependencies

```bash
mt deps                  # Check if dependencies are installed
mt deps --install        # Auto-install missing dependencies (macOS only)
```

### mt edit
Edit function, executable, or file

```bash
mt edit function-name    # Edit a shell function
mt edit command-name     # Edit an executable in bin/
mt edit file-path        # Edit any file
```

### mt install
Symlink package directories (bin, config, shell) using GNU Stow

```bash
mt install               # Install current directory as package
mt install package-name  # Install specific package
mt install path/to/pkg   # Install package from path
mt install -v pkg        # Verbose mode
```

### mt modules
List all metool modules (collections of packages)

```bash
mt modules               # Show all modules
```

### mt packages
List all metool packages with their parent modules

```bash
mt packages              # Show all packages organized by module
```

### mt reload
Reload metool configuration

```bash
mt reload                # Reload shell functions and aliases
```

### mt update
Update metool from git

```bash
mt update                # Pull latest changes from git
```

## Git Commands

### mt git clone
Clone a git repository to canonical location

```bash
mt git clone user/repo          # Clone from GitHub
mt git clone gitlab:user/repo   # Clone from GitLab
mt git clone url                # Clone from URL
```

### mt git repos
List git repositories

```bash
mt git repos             # List all cloned repositories
```

### mt git sync
Sync repositories from repos.txt manifest

```bash
mt git sync              # Clone/update repos listed in .repos.txt
```

### mt git trusted
Check if repository is trusted or list patterns

```bash
mt git trusted           # List trusted repo patterns
mt git trusted path      # Check if path matches trusted pattern
```

## Service Commands (systemd)

### mt enable
Enable systemd service(s) from a package

```bash
mt enable package        # Enable services from package
```

### mt disable
Disable systemd service(s) while preserving service files

```bash
mt disable package       # Disable services from package
```

## Command Options

Most commands support:
- `-h, --help` - Show help message
- `-v, --verbose` - Verbose output (where applicable)

## Environment Variables

- `MT_ROOT` - Path to metool root directory
- `MT_PKG_DIR` - Path to metool package directory (default: ~/.metool)
- `MT_LOG_LEVEL` - Logging level (DEBUG, INFO, etc.)

## Exit Codes

- `0` - Success
- `1` - General error
- `2` - Invalid arguments
- `127` - Command not found or dependency missing
