# Taskmaster MCP Tools Reference

This document provides detailed information about all available Taskmaster MCP tools.

## Task Management Tools

### task_create

Create a new task with full metadata.

**Parameters:**
- `project` (required): Project code (e.g., "TM", "VM", "AG")
- `type` (required): Task type - one of: feat, fix, refactor, docs, test, perf, research, task, epic
- `title` (required): Task title (will be slugified for directory name)
- `priority`: Priority level - critical, high, normal (default), low
- `assigned_to`: Username or identifier
- `tags`: List of tags for categorization
- `due_date`: Due date in YYYY-MM-DD format
- `dependencies`: List of task IDs this task depends on
- `related_tasks`: List of related task IDs
- `parent`: Parent task ID (for subtasks and epics)
- `branch`: Git branch name

**Returns:**
Task object with all metadata including generated task_id and directory path.

**Example:**
```python
task_create(
    project="TM",
    type="feat",
    title="Add export functionality",
    priority="high",
    tags=["cli", "export"]
)
```

### task_list

Query and filter tasks with sorting.

**Parameters:**
- `project`: Filter by project code (auto-detects from git if not provided)
- `status`: Filter by status - pending, active, blocked, review, completed, archived
- `type`: Filter by type - feat, fix, refactor, docs, test, perf, research, task, epic
- `priority`: Filter by priority - critical, high, normal, low
- `tags`: Filter by tags (list)
- `parent`: Filter by parent task ID
- `limit`: Maximum results (default: 20)
- `sort_by`: Sort field with optional - prefix for descending (default: "-created")

**Returns:**
List of task objects matching filters.

**Common Examples:**
```python
# List active tasks in current project
task_list(status="active")

# List all feature tasks
task_list(type="feat", limit=50)

# List critical priority tasks
task_list(priority="critical")

# List subtasks of an epic
task_list(parent="TM-50")
```

### task_get

Retrieve complete details for a specific task.

**Parameters:**
- `task_id` (required): Full task ID (e.g., "TM-42")

**Returns:**
Complete task object with all metadata and content.

### task_update

Update task metadata fields.

**Parameters:**
- `task_id` (required): Full task ID
- `status`: New status value
- `priority`: New priority value
- `assigned_to`: New assignee
- `branch`: Git branch name
- `tags`: New tags list (replaces existing)
- `due_date`: New due date
- `parent`: New parent task ID

**Returns:**
Updated task object.

**Note:** Only provided fields are updated. Omitted fields remain unchanged.

**Example:**
```python
# Mark task as active
task_update(task_id="TM-42", status="active")

# Change priority and add tags
task_update(task_id="VM-10", priority="critical", tags=["bug", "urgent"])
```

### next_task_id

Get the next available task ID for a project.

**Parameters:**
- `project` (required): Project code

**Returns:**
Next task ID as string (e.g., "TM-43")

**Use Case:**
Useful when you need to reference a task ID before creating it, or to check what the next task number will be.

### task_metadata_get

Retrieve specific metadata field(s) from a task.

**Parameters:**
- `task_id` (required): Full task ID
- `field`: Specific field to retrieve (supports dot notation for nested fields)

**Returns:**
Field value or entire task object if no field specified.

**Examples:**
```python
# Get entire task metadata
task_metadata_get("TM-42")

# Get specific field
task_metadata_get("TM-42", "status")

# Get nested field
task_metadata_get("TM-42", "branch")
```

### task_metadata_set

Set a specific metadata field value.

**Parameters:**
- `task_id` (required): Full task ID
- `field` (required): Field name to update
- `value` (required): New value

**Returns:**
Updated task object.

**Example:**
```python
task_metadata_set("TM-42", "status", "completed")
```

## Project Management Tools

### project_list

List all registered projects.

**Returns:**
List of project objects with code, name, and git_url.

### project_get

Get details for a specific project.

**Parameters:**
- `project` (required): Project code or name

**Returns:**
Project object with full details.

### project_create

Create a new project definition.

**Parameters:**
- `code` (required): 2-3 uppercase letter code
- `name` (required): Project name
- `git_url`: Git repository URL

**Returns:**
Created project object.

## Development Tools

### task_worktree

Ensure a git worktree exists for a task. **ALWAYS call this before making code changes to task code.**

**Parameters:**
- `task_id` (required): Full task ID

**Returns:**
Object with status, path, and message.

**Behavior:**
- Creates worktree if it doesn't exist
- Returns path if it already exists
- Automatically determines git repository from project configuration
- Uses pattern: `{task_dir_parent}/{task_id}_{type}_{title_slug}/`

**Example:**
```python
# Ensure worktree before starting development
result = task_worktree("TM-42")
# result["path"] = "/Users/admin/Code/github.com/mbailey/taskmaster-worktrees/TM-42_feat_export/"
```

**Important:** Always call this before editing project code to ensure you're working in the correct isolated environment.

## Validation Tools

### task_validate

Validate task structure and naming conventions.

**Parameters:**
- `target`: What to validate - "all", "task_id", or "directory"
- `project`: Project code to limit validation scope
- `fix`: Boolean - whether to automatically fix issues (default: false)

**Returns:**
Validation report with issues found and fixes applied.

**Use Cases:**
- Validate all tasks before committing changes
- Check if a specific task follows naming conventions
- Auto-fix common issues like incorrect directory names

## Best Practices

### When to Use Each Tool

**Creating Tasks:**
1. Use `task_create` for new tasks
2. Use `next_task_id` if you need to know the ID beforehand

**Finding Tasks:**
1. Use `task_list` with filters for searching
2. Use `task_get` when you have a specific task ID

**Updating Tasks:**
1. Use `task_update` for metadata changes
2. Edit README.md directly for content changes
3. Use `task_metadata_set` for programmatic updates

**Development Workflow:**
1. Create task with `task_create`
2. Set status to active: `task_update(task_id, status="active")`
3. **Call `task_worktree` before code changes**
4. Work in the worktree directory
5. Update status as work progresses
6. Mark complete: `task_update(task_id, status="completed")`

### Auto-Detection Features

- `task_list` auto-detects current project from git repository
- `task_create` can auto-create projects if they don't exist
- `task_worktree` auto-determines git repository from project config

### Common Patterns

**Epic with Subtasks:**
```python
# Create epic
epic = task_create(project="TM", type="epic", title="Major Feature")
epic_id = epic["task_id"]

# Create subtasks
task_create(project="TM", type="feat", title="Component A", parent=epic_id)
task_create(project="TM", type="feat", title="Component B", parent=epic_id)
task_create(project="TM", type="test", title="Integration Tests", parent=epic_id)
```

**Task Dependencies:**
```python
# Create tasks with dependencies
spec = task_create(project="VM", type="task", title="Write specification")
impl = task_create(project="VM", type="feat", title="Implementation",
                   dependencies=[spec["task_id"]])
test = task_create(project="VM", type="test", title="Test suite",
                  dependencies=[impl["task_id"]])
```
