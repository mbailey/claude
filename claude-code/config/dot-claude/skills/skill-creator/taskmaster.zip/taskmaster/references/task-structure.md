# Task Structure and Templates

This document describes the structure of task directories and README files.

## Task Directory Structure

Each task is stored in a directory with this naming convention:

```
{TASK_ID}_{type}_{title_slug}/
```

Examples:
- `TM-65_feat_add-export-functionality/`
- `VM-10_fix_audio-crash-on-startup/`
- `AG-8_refactor_simplify-configuration/`

### Directory Contents

Typical task directory contains:

```
TM-65_feat_add-export-functionality/
├── README.md              # Required: Main task documentation
├── SPEC.md               # Optional: Technical specification
├── ANALYSIS.md           # Optional: Research/analysis findings
├── PLAN.md               # Optional: Implementation planning
└── {other}.md            # Optional: Additional documentation
```

**Only README.md is required.** Other files are created as needed.

## README.md Structure

Every task README.md has two main parts:

### 1. YAML Front Matter (Metadata)

The YAML front matter contains all task metadata and is managed by Taskmaster MCP tools.

**Required Fields:**
```yaml
---
task_id: TM-65           # Auto-generated
title: Task title        # From task creation
status: pending          # Current status
project: TM              # Project code
type: feat               # Task type
priority: normal         # Priority level
created: '2025-10-26 12:00:00'  # Auto-generated
---
```

**Optional Fields:**
```yaml
updated: '2025-10-26 14:30:00'  # Auto-updated
assigned_to: username           # Assignee
due_date: '2025-10-30'         # Due date
tags: [tag1, tag2]             # Tags for filtering
dependencies: [TM-60, TM-62]   # Dependent tasks
related_tasks: [VM-10]         # Related tasks
parent: TM-50                  # Parent epic/task
branch: feat/export            # Git branch
pr_url: https://github.com/... # Pull request URL
```

### 2. Markdown Body (Content)

The markdown body contains the task description, objectives, and implementation details.

## Task Types and Templates

Different task types use different templates. Templates are available in:

```
assets/task-templates/
```

### Available Templates

1. **default.md** - Generic task template
2. **feature.md** - Feature development template
3. **fix.md** - Bug fix template
4. **research.md** - Research/investigation template

### Template Selection by Type

| Type | Template | Use Case |
|------|----------|----------|
| task | default.md | General tasks |
| feat | feature.md | New features |
| fix | fix.md | Bug fixes |
| refactor | default.md or feature.md | Code refactoring |
| docs | default.md | Documentation |
| test | default.md | Test creation |
| perf | default.md or fix.md | Performance improvements |
| research | research.md | Investigation/research |
| epic | feature.md | Multi-task epics |

## Template Contents

### Default Template (task)

```markdown
---
task_id: null
title: null
status: planning
project: null
type: task
priority: normal
created: YYYY-MM-DD
---

# Task: [Brief Description]

## Objective
[Clear statement of what needs to be accomplished]

## Context
- [file/path](relative/path): Description of when to read this
- [Another file](path): Read when implementing X

## Requirements
- [ ] Requirement 1
- [ ] Requirement 2
- [ ] Requirement 3

## Implementation Plan
[Approach and technical details]

## Success Criteria
- [ ] Criteria 1
- [ ] Criteria 2

## Notes
[Any additional information]

## Log
*Append-only activity log - newest entries at bottom*

YYYY-MM-DD HH:MM [INFO] Task created
```

### Feature Template (feat)

```markdown
---
task_id: null
title: null
status: planning
project: null
type: feat
priority: normal
created: YYYY-MM-DD
user_stories: []
acceptance_criteria: []
---

# Feature: [Feature Name]

## Objective
[What feature are we building and why]

## Context
- [Specification doc](path): Read before starting implementation
- [Related PR](url): Previous work to understand
- [Design doc](path): Architecture decisions

## User Story
As a [user type]
I want [functionality]
So that [benefit]

## Requirements

### Functional Requirements
- [ ] Requirement 1
- [ ] Requirement 2

### Non-Functional Requirements
- [ ] Performance requirement
- [ ] Security requirement

## Design

### Technical Design
[Architecture and implementation approach]

### User Interface
[UI/UX considerations if applicable]

## Implementation Plan
1. Step 1
2. Step 2
3. Step 3

### Code Changes
When documenting code changes, use diff format:
```diff
 existing code context
-removed lines
+added lines
 more context
```

## Testing Strategy
- Unit tests for [components]
- Integration tests for [workflows]
- User acceptance criteria

## Success Criteria
- [ ] Feature works as specified
- [ ] Tests are passing
- [ ] Documentation is updated
- [ ] Code is reviewed

## Notes
[Dependencies, risks, assumptions]

## Log
*Append-only activity log - newest entries at bottom*

YYYY-MM-DD HH:MM [INFO] Feature task created
```

### Fix Template (fix)

```markdown
---
task_id: null
title: null
status: planning
project: null
type: fix
priority: normal
created: YYYY-MM-DD
---

# Fix: [Issue Description]

## Problem
[Clear description of the bug or issue]

## Impact
- Severity: [Critical/High/Medium/Low]
- Affected users: [Who is impacted]
- Workaround: [If any exists]

## Steps to Reproduce
1. Step 1
2. Step 2
3. Observe error

## Expected Behavior
[What should happen]

## Actual Behavior
[What currently happens]

## Root Cause
[Analysis of why the issue occurs]

## Solution
[Proposed fix approach]

## Testing
- [ ] Reproducer test added
- [ ] Edge cases covered
- [ ] Regression tests pass

## Success Criteria
- [ ] Issue no longer reproducible
- [ ] Tests passing
- [ ] No regressions introduced

## Notes
[Additional context, related issues]

## Log
*Append-only activity log*

YYYY-MM-DD HH:MM [INFO] Fix task created
```

### Research Template (research)

```markdown
---
task_id: null
title: null
status: planning
project: null
type: research
priority: normal
created: YYYY-MM-DD
---

# Research: [Topic]

## Objective
[What needs to be researched and why]

## Questions to Answer
- Question 1
- Question 2
- Question 3

## Approach
[How the research will be conducted]

## Findings
[Document discoveries here]

## Recommendations
[Based on research, what should be done]

## Resources
- [Resource 1](url)
- [Resource 2](url)

## Success Criteria
- [ ] All questions answered
- [ ] Recommendations documented
- [ ] Decision made

## Log
*Research progress and findings*

YYYY-MM-DD HH:MM [INFO] Research task created
```

## Metadata Field Details

### Status Values

- `pending` - Not started (default)
- `planning` - Planning phase
- `active` - Currently being worked on
- `blocked` - Waiting on dependencies
- `review` - Code review / PR review
- `completed` - Finished and merged
- `archived` - Historical record

### Type Values

- `feat` - New feature
- `fix` - Bug fix
- `refactor` - Code refactoring
- `docs` - Documentation
- `test` - Test creation/improvement
- `perf` - Performance improvement
- `research` - Investigation/research
- `task` - Generic task
- `epic` - Large multi-task initiative

### Priority Values

- `critical` - Urgent, blocking
- `high` - Important, soon
- `normal` - Standard priority (default)
- `low` - Nice to have

## Using Templates

### When Creating Tasks via MCP

Templates are automatically applied based on task type:

```python
task_create(
    project="TM",
    type="feat",
    title="Add export functionality"
)
# Automatically uses feature.md template
```

### When Creating Tasks Manually

If creating task directories manually:

1. Copy appropriate template from `assets/task-templates/`
2. Rename to `README.md`
3. Fill in metadata fields
4. Replace template placeholders with actual content

## Content Guidelines

### Objective Section

- Start with "Implement...", "Fix...", "Research...", etc.
- Be specific about what will be accomplished
- Explain why this task is important

### Context Section

- Link to related files, PRs, docs
- Provide file paths relative to project root
- Note when each resource should be consulted

### Requirements Section

- Use checkboxes for tracking progress
- Be specific and measurable
- Separate functional and non-functional requirements

### Implementation Plan

- Break down into logical steps
- Order steps by dependency
- Include testing and documentation steps

### Success Criteria

- Define "done" clearly
- Include testing requirements
- Specify documentation updates needed

### Log Section

- Append-only (newest at bottom)
- Format: `YYYY-MM-DD HH:MM [LEVEL] Message`
- Levels: INFO, WARN, ERROR, DEBUG
- Track major decisions and progress

## Progress Tracking with Checkboxes

Checkboxes in the README are automatically counted for progress tracking:

```markdown
## Requirements
- [x] Completed requirement
- [ ] Pending requirement
- [x] Another completed item
```

This shows as "2/3" progress in task listings.

## Best Practices

### DO:

✅ Use templates appropriate for task type
✅ Keep objectives clear and concise
✅ Use checkboxes for trackable items
✅ Update log section with major changes
✅ Link to related resources in Context
✅ Use diff format for code changes
✅ Keep requirements measurable

### DON'T:

❌ Edit YAML front matter directly (use MCP tools)
❌ Leave template placeholders unfilled
❌ Create overly long objectives
❌ Skip success criteria
❌ Forget to update checkboxes as work progresses
❌ Mix task content with implementation details

## Example Complete Task

```markdown
---
task_id: TM-65
title: Add task list markdown export tool
status: active
project: taskmaster
type: feat
priority: normal
created: '2025-10-16 17:20:18'
tags: [mcp, cli, export]
branch: feat/export-task-list
updated: '2025-10-26 14:30:00'
---

# Add task list markdown export tool

## Objective

Implement a task list export feature that generates markdown-formatted task lists with filtering options, available via both CLI and MCP interface.

## Context

- [MCP tools](../src/taskmaster/mcp/tools/): See existing tool patterns
- [CLI implementation](../src/taskmaster/cli.py): For CLI command structure
- Related to TM-60 (reduce token usage) - keep descriptions concise

## Requirements

### Functional Requirements
- [x] Export tasks as markdown checkboxes
- [x] Support filtering by project, status, type
- [ ] Generate relative links to task READMEs
- [ ] Implement as MCP tool
- [ ] Implement as CLI command

### Non-Functional Requirements
- [ ] Fast performance (<1s for 100 tasks)
- [ ] Clean, readable markdown output

## Implementation Plan

1. Create export function in core module
2. Add MCP tool wrapper
3. Add CLI command
4. Write tests
5. Update documentation

## Testing Strategy

- Unit tests for export formatting
- Integration tests for filters
- CLI command testing
- MCP tool testing

## Success Criteria

- [x] Export generates valid markdown
- [ ] All filters work correctly
- [ ] Tests passing
- [ ] Documentation updated

## Notes

Consider adding JSON export format in future.

## Log

2025-10-16 17:20 [INFO] Task created
2025-10-26 10:15 [INFO] Started implementation
2025-10-26 14:30 [INFO] Core export function complete
```
