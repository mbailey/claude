# Software Development Workflow

This document describes the recommended workflow for working with tasks that involve code changes, git operations, and pull requests.

## Core Principles

1. **Always use worktrees** - Call `task_worktree` before making code changes
2. **Work in isolation** - Each task gets its own worktree directory
3. **Follow git best practices** - Clear commits, descriptive messages, proper branching
4. **Update task status** - Keep task metadata in sync with work progress

## Standard Task Workflow

### 1. Task Creation

```python
# Create a new task
task = task_create(
    project="TM",
    type="feat",
    title="Add export functionality",
    priority="normal"
)
task_id = task["task_id"]  # e.g., "TM-65"
```

### 2. Set Task to Active

```python
# Mark the task as active before starting work
task_update(task_id=task_id, status="active")
```

### 3. Create Worktree

**CRITICAL:** Always call `task_worktree` before making code changes.

```python
# Ensure worktree exists
worktree = task_worktree(task_id)
worktree_path = worktree["path"]
# e.g., "/Users/admin/Code/github.com/mbailey/taskmaster-worktrees/TM-65_feat_export/"
```

The worktree will:
- Be created in the project's worktree directory
- Have its own git branch based on the task
- Be isolated from the main working directory

### 4. Development Work

Work in the worktree directory:

```bash
cd {worktree_path}
# Make your code changes
# Run tests
# Verify functionality
```

**Important:** All code changes must happen in the worktree, not the main repo directory.

### 5. Git Operations

#### Committing Changes

Follow these git commit best practices:

**Commit Message Format:**
```
type(scope): Brief description

Longer explanation if needed.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `refactor`: Code refactoring
- `docs`: Documentation changes
- `test`: Test additions/changes
- `perf`: Performance improvements
- `chore`: Maintenance tasks

**Example:**
```bash
cd {worktree_path}
git add .
git commit -m "feat(export): Add task list export functionality

Implements markdown export with filtering options.
Adds CLI command and MCP tool for exporting task lists.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

#### Pushing Changes

```bash
# Push the branch to remote
git push -u origin {branch_name}
```

### 6. Update Task Status

After pushing changes:

```python
# Update task status and branch info
task_update(
    task_id=task_id,
    status="review",
    branch="feat/export-functionality"
)
```

### 7. Creating Pull Requests

Use the GitHub CLI (`gh`) for PR creation:

```bash
cd {worktree_path}
gh pr create --title "feat(export): Add task list export functionality" \
  --body "## Summary
- Adds task list export functionality
- Implements CLI command: tm task export
- Adds MCP tool: task_export

## Test plan
- [ ] Test CLI export command
- [ ] Test MCP tool
- [ ] Verify markdown formatting
- [ ] Test with various filters

Related: {task_id}

🤖 Generated with [Claude Code](https://claude.com/claude-code)"
```

After PR is created:

```python
# Update task with PR URL
task_update(
    task_id=task_id,
    pr_url="https://github.com/mbailey/taskmaster/pull/123"
)
```

### 8. Task Completion

After PR is merged:

```python
# Mark task as completed
task_update(task_id=task_id, status="completed")
```

## Working with Task README

Each task has a README.md file in its task directory (not the worktree). This file contains:

### README Structure

1. **YAML Front Matter** - Metadata managed by MCP tools
2. **Task Content** - Objectives, requirements, implementation notes

### When to Edit README Directly vs Use MCP Tools

**Use MCP tools for:**
- Status changes
- Priority updates
- Tags, dependencies, assignments
- Any YAML front matter fields

**Edit README directly for:**
- Task objectives and descriptions
- Requirements and specifications
- Implementation notes
- Progress logs
- Any content in the markdown body

### README Location

```
~/tasks/projects/{project}/{task_id}_{type}_{title}/README.md
```

**Example:**
```
~/tasks/projects/taskmaster/TM-65_feat_export-functionality/README.md
```

## Creating Specifications and Reports

When agents need to create specifications or analysis reports for a task:

### File Locations

Store additional task files in the task directory:

```
~/tasks/projects/{project}/{task_id}_{type}_{title}/
├── README.md              # Main task doc (always present)
├── SPEC.md               # Technical specification
├── ANALYSIS.md           # Analysis or research findings
├── PLAN.md               # Implementation plan
└── {other_docs}.md       # Any other relevant docs
```

### Example: Creating a Specification

```python
# When asking an agent to create a spec
task = task_get("TM-65")
task_dir = task["path"]  # e.g., "~/tasks/projects/taskmaster/TM-65_feat_export/"

spec_path = f"{task_dir}/SPEC.md"

# Agent should write specification to spec_path
# Specification should include:
# - Technical design
# - API specifications
# - Data structures
# - Algorithm details
```

## Task States and Transitions

### Status Workflow

```
pending → active → review → completed → archived
         ↘     ↗
          blocked
```

### Status Meanings

- **pending**: Not yet started (default)
- **active**: Currently being worked on
- **blocked**: Waiting on dependencies or external factors
- **review**: Code complete, awaiting review/approval
- **completed**: Fully done and merged
- **archived**: Historical record, no longer relevant

### Best Practices

1. **Move to active when starting** - Signals you're working on it
2. **Use blocked with notes** - Document what's blocking in README
3. **Move to review when code is ready** - PR created, tests passing
4. **Mark completed only after merge** - Not before
5. **Archive old completed tasks** - Keep active list manageable

## Common Patterns

### Bug Fix Workflow

```python
# 1. Create bug fix task
task = task_create(project="TM", type="fix", title="Fix export crash", priority="high")

# 2. Set active and create worktree
task_update(task["task_id"], status="active")
worktree = task_worktree(task["task_id"])

# 3. Fix in worktree, test, commit
# 4. Push and create PR
# 5. Update status
task_update(task["task_id"], status="review", branch="fix/export-crash")
```

### Feature with Spec Workflow

```python
# 1. Create feature task
task = task_create(project="VM", type="feat", title="Add voice cloning")

# 2. Create specification first
task_dir = task_get(task["task_id"])["path"]
# Write SPEC.md to {task_dir}/SPEC.md

# 3. Review spec, then set active
task_update(task["task_id"], status="active")

# 4. Create worktree and implement
worktree = task_worktree(task["task_id"])
# Implement in worktree
```

### Epic with Subtasks Workflow

```python
# 1. Create epic
epic = task_create(project="TM", type="epic", title="Export System")

# 2. Create subtasks
spec_task = task_create(project="TM", type="task", title="Export spec",
                        parent=epic["task_id"])
impl_task = task_create(project="TM", type="feat", title="Export implementation",
                        parent=epic["task_id"],
                        dependencies=[spec_task["task_id"]])
test_task = task_create(project="TM", type="test", title="Export tests",
                        parent=epic["task_id"],
                        dependencies=[impl_task["task_id"]])

# 3. Work through subtasks in order
# 4. Epic auto-tracks progress from subtasks
```

## Tips for AI Agents

### Before Starting Development

1. **Always call task_worktree first** - Never skip this step
2. **Check for dependencies** - Read related tasks and specs
3. **Understand the context** - Read the project CLAUDE.md or README
4. **Verify tests exist** - Know how to validate your changes

### During Development

1. **Work in the worktree path** - Not the main repo
2. **Run tests frequently** - Don't wait until the end
3. **Commit logically** - Small, focused commits
4. **Update README** - Document decisions and progress

### Before Completing

1. **All tests passing** - No shortcuts
2. **Documentation updated** - Code changes reflected in docs
3. **Clean commit history** - Logical progression
4. **PR created and linked** - task updated with pr_url

### Common Mistakes to Avoid

1. ❌ Making code changes without calling task_worktree
2. ❌ Editing files in the main repo instead of worktree
3. ❌ Marking task completed before PR is merged
4. ❌ Forgetting to update task status during workflow
5. ❌ Not documenting blocking issues in README
6. ❌ Creating PRs without descriptive summaries
7. ❌ Skipping tests before committing

## Git Branch Naming

### Automatic Branch Naming

The `task_worktree` tool creates branches using this pattern:

```
{type}/{task_id}-{slugified-title}
```

Examples:
- `feat/TM-65-export-functionality`
- `fix/VM-10-audio-crash`
- `refactor/AG-8-simplify-config`

### Manual Branch Naming

If you need to specify a branch manually:

```python
task_update(task_id="TM-65", branch="feat/custom-branch-name")
```

## Worktree Management

### Worktree Location

Worktrees are created in:

```
{project_repo_dir}-worktrees/{task_dir_name}/
```

Example:
```
/Users/admin/Code/github.com/mbailey/taskmaster-worktrees/TM-65_feat_export/
```

### Cleaning Up Worktrees

After a task is completed and merged:

```bash
# List worktrees
git worktree list

# Remove completed task worktree
git worktree remove {worktree_path}
```

## Integration with Other Tools

### Using with Claude Code

When using Claude Code's built-in git features:

1. Claude Code will handle commits with proper formatting
2. PR creation uses gh CLI automatically
3. Co-authorship attribution is added automatically

### Using with MCP Tools

All task operations should use MCP tools when available:

```python
# ✅ Good - Use MCP tools
task_update(task_id, status="active")

# ❌ Bad - Don't edit YAML directly
# Edit ~/tasks/projects/TM/TM-65.../README.md
```

## Summary Checklist

For every task involving code changes:

- [ ] Create task with task_create
- [ ] Set status to active
- [ ] **Call task_worktree before any code changes**
- [ ] Work in worktree directory
- [ ] Make commits with proper format
- [ ] Run and pass all tests
- [ ] Push branch to remote
- [ ] Create PR with gh CLI
- [ ] Update task with branch and pr_url
- [ ] Set status to review
- [ ] After merge, set status to completed
