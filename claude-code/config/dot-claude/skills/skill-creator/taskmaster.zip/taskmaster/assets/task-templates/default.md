---
# Base fields sourced from @.ai/templates/task-base.yaml
task_id: null  # PROJECT-NUMBER (e.g., VOI-1, AGT-23)
title: null
status: planning  # planning|active|blocked|completed|archived
project: null
git_url: null  # Repository URL for agents to find the code
type: task
priority: normal  # critical|high|normal|low
created: YYYY-MM-DD
updated: null  # Auto-set when task is modified

# Optional common fields
assigned_to: null
due_date: null
tags: []
dependencies: []
related_tasks: []
branch: null
pr_url: null

# Task type specific properties
# (none for default task type)
---

# Task: [Brief Description]

## Objective
[Clear statement of what needs to be accomplished]

## Context
- [file/path](relative/path): Description of when to read this
- [Another file](path): Read when implementing X
- [External resource](https://url): Reference for Y

## Requirements
- [ ] Requirement 1
- [ ] Requirement 2
- [ ] Requirement 3

## Implementation Plan
[Approach and technical details]

## Success Criteria
- [ ] Criteria 1
- [ ] Criteria 2

## Notes
[Any additional information]

## Log
*Append-only activity log - newest entries at bottom*

YYYY-MM-DD HH:MM [INFO] Task created