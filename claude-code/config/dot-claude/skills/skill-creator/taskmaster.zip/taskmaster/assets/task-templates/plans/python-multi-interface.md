# Implementation Plan: Python Multi-Interface Package

## Overview
This template provides a standard plan for implementing Python packages that expose functionality through multiple interfaces: CLI, MCP Tools, REST API, and Web UI.

## Architecture Pattern
```
Models (Core Data Structures)
    ↓
Storage/Service Layer (Business Logic)
    ↓
    ├── CLI (Click)
    ├── MCP Tools (FastMCP)
    ├── API (FastAPI/Flask)
    └── Web UI (Streamlit/Django)
```

## Phase Structure & Dependencies

### Phase 1: Foundation (Sequential - 1 developer)
**Must be completed first - all other phases depend on this**

#### 1.1 Package Setup (30 min)
```
project_name/
├── src/
│   └── package_name/
│       ├── __init__.py
│       ├── __version__.py
│       ├── models/
│       ├── storage/
│       ├── services/
│       ├── cli/
│       ├── mcp/
│       ├── api/
│       └── web/
├── tests/
├── pyproject.toml
└── README.md
```

#### 1.2 Core Models (1-2 hours)
- Define data structures
- Implement validation
- Create serialization methods (to_dict, from_dict)
- Add type hints throughout

#### 1.3 Storage/Service Layer (1-2 hours)
- Abstract storage interface
- File-based implementation
- Business logic methods
- Error handling

### Phase 2: Interface Implementation (Parallel - up to 4 developers)
**Can be done in parallel once Phase 1 is complete**

#### 2.1 CLI Interface (1 developer)
**Dependencies:** Models, Storage
**Time:** 1-2 hours
**Stack:** Click + Rich

```python
# Structure
cli/
├── __init__.py
├── app.py           # Main CLI entry
└── commands/
    ├── create.py
    ├── list.py
    └── ...
```

**Tasks:**
- [ ] Setup Click application
- [ ] Implement each command
- [ ] Add help documentation
- [ ] Format output with Rich
- [ ] Add to pyproject.toml entry points

#### 2.2 MCP Tools (1 developer)
**Dependencies:** Models, Storage
**Time:** 1-2 hours
**Stack:** FastMCP

```python
# Structure
mcp/
├── __init__.py
├── server.py        # FastMCP server
└── tools/
    ├── create.py
    ├── list.py
    └── ...
```

**Tasks:**
- [ ] Setup FastMCP server
- [ ] Create tool decorators
- [ ] Map to storage methods
- [ ] Add tool descriptions
- [ ] Test with MCP client

#### 2.3 REST API (1 developer)
**Dependencies:** Models, Storage
**Time:** 2-3 hours
**Stack:** FastAPI or Flask

```python
# Structure
api/
├── __init__.py
├── app.py           # FastAPI app
├── routes/
│   ├── items.py
│   └── ...
└── schemas/
    └── ...
```

**Tasks:**
- [ ] Setup FastAPI application
- [ ] Define API routes
- [ ] Create request/response schemas
- [ ] Add authentication (if needed)
- [ ] Generate OpenAPI docs
- [ ] Add CORS configuration

#### 2.4 Web UI (1 developer)
**Dependencies:** Models, Storage (or API)
**Time:** 2-4 hours
**Stack:** Streamlit, Gradio, or Django

```python
# Structure
web/
├── __init__.py
├── app.py           # Main web app
├── pages/
│   ├── home.py
│   └── ...
└── components/
    └── ...
```

**Tasks:**
- [ ] Setup web framework
- [ ] Create main pages
- [ ] Implement forms
- [ ] Add data visualization
- [ ] Style with CSS
- [ ] Deploy configuration

### Phase 3: Integration & Testing (1 developer)
**After all interfaces are complete**

#### 3.1 Integration Tests (1 hour)
- Test each interface
- Verify shared storage works
- Check data consistency

#### 3.2 Documentation (30 min)
- Update README with all interfaces
- Add usage examples
- Document deployment

## Parallelization Strategy

### Optimal Team Size: 3-4 developers

**Developer 1 (Lead):**
- Phase 1: Complete foundation
- Phase 2: Oversee integration
- Phase 3: Testing & documentation

**Developer 2:**
- Wait for Phase 1
- Phase 2: Implement CLI + MCP Tools

**Developer 3:**
- Wait for Phase 1
- Phase 2: Implement REST API

**Developer 4 (if available):**
- Wait for Phase 1 (or API if using API backend)
- Phase 2: Implement Web UI

## Communication Between Interfaces

### Shared Code Patterns

```python
# All interfaces call the same storage methods
def handle_create_request(data):
    # Validate input (interface-specific)
    validated = validate_input(data)

    # Call shared storage layer
    item = storage.create_item(validated)

    # Format response (interface-specific)
    return format_response(item)
```

### Key Principles

1. **Models are contracts** - All interfaces use the same model classes
2. **Storage is singleton** - One storage instance shared by all
3. **Business logic in storage** - Not duplicated in interfaces
4. **Interface layers are thin** - Just translation and formatting
5. **Test the core first** - Models and storage before interfaces

## Handoff Instructions

When handing off to implementation agents:

### For CLI Developer
"Implement the CLI interface using Click. The models and storage are already complete. Reference src/package_name/storage/ for available methods. See src/package_name/models/ for data structures. Create commands for: [list specific commands]. Use Rich for output formatting."

### For MCP Developer
"Implement MCP tools using FastMCP. Models and storage are complete. Wrap storage methods from src/package_name/storage/ as MCP tools. Each tool should map to one storage method. Include proper descriptions and type hints."

### For API Developer
"Implement REST API using FastAPI. Models and storage are complete. Create routes that call storage methods from src/package_name/storage/. Use models from src/package_name/models/ for request/response schemas. Include OpenAPI documentation."

### For Web Developer
"Implement web UI using [Streamlit/Gradio/Django]. Models and storage are complete. Call storage methods from src/package_name/storage/ or use the API at [endpoint]. Create pages for: [list pages]. Focus on user experience."

## Common Pitfalls to Avoid

1. **Don't duplicate business logic** - Keep it in storage/services
2. **Don't create interface-specific models** - Share core models
3. **Don't bypass storage layer** - All data access through storage
4. **Don't forget error handling** - Each interface handles differently
5. **Don't mix concerns** - Keep interfaces separate

## Success Metrics

- [ ] All interfaces can perform CRUD operations
- [ ] Changes through one interface visible in others
- [ ] Each interface has its own tests
- [ ] Documentation includes examples for each interface
- [ ] Package installs cleanly with all extras

## Example Dependencies

```toml
# pyproject.toml
[project]
dependencies = [
    "pydantic>=2.0",
    "pyyaml>=6.0",
]

[project.optional-dependencies]
cli = ["click>=8.1", "rich>=13.0"]
mcp = ["fastmcp>=0.5"]
api = ["fastapi>=0.100", "uvicorn>=0.20"]
web = ["streamlit>=1.25"]
all = ["package_name[cli,mcp,api,web]"]
```

## Notes

- This template assumes a Python package with local file storage
- Adjust timings based on complexity
- Consider using a task queue for long operations
- Add authentication/authorization as needed
- Consider containerization for deployment