---
# Base fields sourced from @.ai/templates/task-base.yaml
task_id: null  # PROJECT-NUMBER (e.g., VOI-1, AGT-23)
title: null
status: planning  # planning|active|blocked|completed|archived
project: null
type: research
priority: normal  # critical|high|normal|low
created: YYYY-MM-DD
updated: null  # Auto-set when task is modified

# Optional common fields
assigned_to: null
due_date: null
tags: []
dependencies: []
related_tasks: []
branch: null
pr_url: null

# Task type specific properties
research_questions: []
findings_summary: null
recommendations: []
---

# Research: [Topic]

## Objective
[What are we trying to learn or discover]

## Context
- [Previous research](path): Related investigations
- [Documentation](url): Official docs to review
- [Reference implementation](url): Example to study

## Research Questions
1. Question 1?
2. Question 2?
3. Question 3?

## Methodology
[How will we conduct the research]

## Resources
- Resource 1
- Resource 2
- Resource 3

## Findings
### Finding 1
[Details]

### Finding 2
[Details]

## Recommendations
Based on the research:
1. Recommendation 1
2. Recommendation 2

## Next Steps
- [ ] Action item 1
- [ ] Action item 2

## Notes
[Additional observations, limitations]

## Log
*Append-only activity log - newest entries at bottom*

YYYY-MM-DD HH:MM [INFO] Research task created