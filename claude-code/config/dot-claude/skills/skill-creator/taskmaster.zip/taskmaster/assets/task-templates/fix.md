---
# Base fields sourced from @.ai/templates/task-base.yaml
task_id: null  # PROJECT-NUMBER (e.g., VOI-1, AGT-23)
title: null
status: planning  # planning|active|blocked|completed|archived
project: null
type: fix
priority: normal  # critical|high|normal|low
created: YYYY-MM-DD
updated: null  # Auto-set when task is modified

# Optional common fields
assigned_to: null
due_date: null
tags: []
dependencies: []
related_tasks: []
branch: null
pr_url: null

# Task type specific properties
issue_url: null
severity: null  # critical|major|minor|trivial
affected_versions: []
fixed_in_version: null
---

# Fix: [Bug Description]

## Problem
[Clear description of the bug/issue]

## Context
- [Issue link](url): Original bug report
- [Error logs](path): Stack traces and error messages
- [Related code](path): Files where bug occurs

## Expected Behavior
[What should happen]

## Actual Behavior
[What actually happens]

## Steps to Reproduce
1. Step 1
2. Step 2
3. Step 3

## Root Cause Analysis
[Investigation findings]

## Solution
[Proposed fix approach]

### Code Changes
When documenting code changes, use diff format for clarity:
```diff
 existing code context
-removed lines (causing bug)
+added lines (fixing bug)
 more context
```

## Testing
- [ ] Verify fix resolves the issue
- [ ] Check for regressions
- [ ] Add tests to prevent recurrence

## Success Criteria
- [ ] Bug is fixed
- [ ] Tests pass
- [ ] No new issues introduced

## Notes
[Related issues, workarounds]

## Log
*Append-only activity log - newest entries at bottom*

YYYY-MM-DD HH:MM [INFO] Bug fix task created