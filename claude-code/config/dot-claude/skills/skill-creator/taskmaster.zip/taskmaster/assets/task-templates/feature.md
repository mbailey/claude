---
# Base fields sourced from @.ai/templates/task-base.yaml
task_id: null  # PROJECT-NUMBER (e.g., VOI-1, AGT-23)
title: null
status: planning  # planning|active|blocked|completed|archived
project: null
git_url: null  # Repository URL for agents to find the code
type: feat
priority: normal  # critical|high|normal|low
created: YYYY-MM-DD
updated: null  # Auto-set when task is modified

# Optional common fields
assigned_to: null
due_date: null
tags: []
dependencies: []
related_tasks: []
branch: null
pr_url: null

# Task type specific properties
user_stories: []
acceptance_criteria: []
technical_specs: null
---

# Feature: [Feature Name]

## Objective
[What feature are we building and why]

## Context
- [Specification doc](path): Read before starting implementation
- [Related PR](url): Previous work to understand
- [Design doc](path): Architecture decisions

## User Story
As a [user type]
I want [functionality]
So that [benefit]

## Requirements
### Functional Requirements
- [ ] Requirement 1
- [ ] Requirement 2

### Non-Functional Requirements
- [ ] Performance requirement
- [ ] Security requirement

## Design
### Technical Design
[Architecture and implementation approach]

### User Interface
[UI/UX considerations if applicable]

## Implementation Plan
1. Step 1
2. Step 2
3. Step 3

### Code Changes
When documenting code changes, use diff format for clarity:
```diff
 existing code context
-removed lines with minus
+added lines with plus
 more context
```

## Testing Strategy
- Unit tests for [components]
- Integration tests for [workflows]
- User acceptance criteria

## Success Criteria
- [ ] Feature works as specified
- [ ] Tests are passing
- [ ] Documentation is updated
- [ ] Code is reviewed

## Notes
[Dependencies, risks, assumptions]

## Log
*Append-only activity log - newest entries at bottom*

YYYY-MM-DD HH:MM [INFO] Feature task created