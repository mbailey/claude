---
name: taskmaster
description: Comprehensive task management using Taskmaster MCP tools. Use this skill when working with tasks - creating, searching, updating, organizing tasks and epics, managing task workflows, preparing specifications, or handling development workflows with git worktrees. Also applies when the user asks about task management, wants to review tasks, needs to create subtasks for epics, or is working within a task directory.
---

# Taskmaster

## Overview

Taskmaster provides structured task management following the Model Line 7 workflow with git integration, MCP tools, and organized task directories. Use this skill for all task-related operations including creation, search, updates, development workflows, and documentation.

## When to Use This Skill

Use the taskmaster skill when:

- Creating new tasks, features, bugs, or research items
- Searching for existing tasks by keyword, status, or tags
- Updating task metadata (status, priority, assignments)
- Working with task hierarchies (epics and subtasks)
- Starting development work that requires a git worktree
- Creating specifications or reports within task directories
- Managing task workflows (pending → active → review → completed)
- Reviewing project tasks or generating task lists

## Core Workflow

### 1. Creating Tasks

Use `task_create` to create new tasks with proper metadata:

```python
# Create a feature task
task = task_create(
    project="TM",              # Project code (TM, VM, AG, etc.)
    type="feat",               # feat, fix, refactor, docs, test, perf, research, task, epic
    title="Add export functionality",
    priority="normal",         # critical, high, normal, low
    tags=["cli", "mcp"]       # Optional tags for organization
)

# Create a subtask for an epic
subtask = task_create(
    project="VM",
    type="feat",
    title="Implement audio processing",
    parent="VM-50",           # Parent epic task ID
    dependencies=["VM-48"]    # Depends on other task
)
```

**Project code auto-detection:** If working in a git repository with a registered project, the `project` parameter can be omitted and will auto-detect.

### 2. Searching and Listing Tasks

Use `task_list` with filters to find tasks:

```python
# List active tasks in current project
tasks = task_list(status="active")

# Find all feature tasks with high priority
tasks = task_list(type="feat", priority="high", limit=50)

# List subtasks of an epic
subtasks = task_list(parent="TM-50")

# Search by tags
tasks = task_list(tags=["bug", "urgent"])
```

**Common search patterns:**
- Current project active tasks: `task_list(status="active")`
- All pending features: `task_list(type="feat", status="pending")`
- Blocked tasks needing attention: `task_list(status="blocked")`
- Critical priority across all projects: `task_list(priority="critical", project=None)`

### 3. Updating Task Status

Use `task_update` to change task metadata:

```python
# Mark task as active when starting work
task_update(task_id="TM-65", status="active")

# Increase priority
task_update(task_id="VM-10", priority="critical")

# Add tags and branch info
task_update(
    task_id="TM-65",
    tags=["export", "cli", "mcp"],
    branch="feat/export-functionality"
)

# Update after PR creation
task_update(
    task_id="TM-65",
    status="review",
    pr_url="https://github.com/mbailey/taskmaster/pull/123"
)
```

### 4. Working with Worktrees (CRITICAL for Development)

**ALWAYS call `task_worktree` before making any code changes to a project.**

```python
# Ensure worktree exists before development
result = task_worktree("TM-65")
worktree_path = result["path"]
# Returns: "/Users/admin/Code/github.com/mbailey/taskmaster-worktrees/TM-65_feat_export/"

# Now work in the worktree directory
# All code changes must happen in worktree, not main repo
```

**Why worktrees matter:**
- Isolates each task's code changes
- Prevents conflicts between multiple tasks
- Enables clean git workflows with separate branches
- Required before any code modifications

### 5. Task README Management

Each task has a README.md in its task directory:

**Location:**
```
~/tasks/projects/{project}/{task_id}_{type}_{title}/README.md
```

**Structure:**
- **YAML front matter**: Metadata managed by MCP tools
- **Markdown body**: Task content you edit directly

**Edit metadata via MCP:**
```python
# Use MCP tools for metadata
task_update(task_id="TM-65", status="active")
```

**Edit content directly:**
- Task objectives and descriptions
- Requirements and checklists
- Implementation notes
- Progress logs

**Creating additional task files:**

Store specs, analyses, and plans in the task directory:

```python
# Get task directory path
task = task_get("TM-65")
task_dir = task["path"]

# Create specification
spec_path = f"{task_dir}/SPEC.md"
# Write specification to spec_path

# Create analysis
analysis_path = f"{task_dir}/ANALYSIS.md"
# Write analysis to analysis_path
```

Common additional files:
- `SPEC.md` - Technical specifications
- `ANALYSIS.md` - Research findings
- `PLAN.md` - Implementation planning
- `NOTES.md` - Development notes

## Development Workflow

### Standard Task Development Cycle

Follow these steps for tasks involving code changes:

**1. Create and activate task:**
```python
task = task_create(project="TM", type="feat", title="Add export tool")
task_id = task["task_id"]
task_update(task_id=task_id, status="active")
```

**2. Create worktree (REQUIRED before code changes):**
```python
worktree = task_worktree(task_id)
# Work in worktree["path"] for all code changes
```

**3. Develop in worktree:**
```bash
cd {worktree_path}
# Make code changes
# Run tests
# Commit with proper format
```

**4. Commit with proper format:**
```bash
git add .
git commit -m "feat(export): Add export functionality

Implements CLI and MCP tools for task export.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>"
```

**5. Push and create PR:**
```bash
git push -u origin {branch_name}
gh pr create --title "feat(export): Add export functionality" --body "..."
```

**6. Update task:**
```python
task_update(
    task_id=task_id,
    status="review",
    branch="feat/export-tool",
    pr_url="https://github.com/..."
)
```

**7. After merge, mark complete:**
```python
task_update(task_id=task_id, status="completed")
```

### Git Commit Message Format

Use conventional commit format:

```
type(scope): Brief description

Longer explanation if needed.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude <noreply@anthropic.com>
```

**Types:**
- `feat`: New feature
- `fix`: Bug fix
- `refactor`: Code refactoring
- `docs`: Documentation
- `test`: Tests
- `perf`: Performance

## Working with Epics and Subtasks

### Creating Epic Structures

```python
# 1. Create parent epic
epic = task_create(
    project="TM",
    type="epic",
    title="Export System",
    priority="high"
)
epic_id = epic["task_id"]

# 2. Create subtasks
spec = task_create(
    project="TM",
    type="task",
    title="Export specification",
    parent=epic_id
)

implementation = task_create(
    project="TM",
    type="feat",
    title="Export implementation",
    parent=epic_id,
    dependencies=[spec["task_id"]]  # Depends on spec
)

tests = task_create(
    project="TM",
    type="test",
    title="Export test suite",
    parent=epic_id,
    dependencies=[implementation["task_id"]]
)
```

### Querying Epic Progress

```python
# Get all subtasks for an epic
subtasks = task_list(parent="TM-50")

# Check epic details
epic = task_get("TM-50")
```

## Task Templates

Templates are available in `assets/task-templates/` for different task types:

- **default.md** - Generic tasks
- **feature.md** - Feature development (type: feat)
- **fix.md** - Bug fixes (type: fix)
- **research.md** - Research tasks (type: research)

Templates are automatically applied when creating tasks based on the `type` parameter.

## MCP Tools Reference

For detailed information on all MCP tools, see `references/mcp-tools.md`.

**Quick reference:**

| Tool | Purpose |
|------|---------|
| `task_create` | Create new task |
| `task_list` | Query/filter tasks |
| `task_get` | Get task details |
| `task_update` | Update task metadata |
| `task_worktree` | Create/ensure git worktree |
| `next_task_id` | Get next task ID |
| `project_list` | List all projects |
| `project_get` | Get project details |
| `task_validate` | Validate task structure |

## Common Patterns and Examples

### Pattern: Bug Fix Workflow

```python
# 1. Create bug fix task
bug = task_create(
    project="VM",
    type="fix",
    title="Fix audio crash on startup",
    priority="critical",
    tags=["bug", "audio"]
)

# 2. Set active and create worktree
task_update(bug["task_id"], status="active")
worktree = task_worktree(bug["task_id"])

# 3. Fix in worktree, test, commit
# 4. Push and PR
# 5. Update status
task_update(
    task_id=bug["task_id"],
    status="review",
    branch="fix/audio-crash"
)
```

### Pattern: Feature with Specification

```python
# 1. Create feature task
feature = task_create(project="TM", type="feat", title="Voice cloning")

# 2. Write specification first
task = task_get(feature["task_id"])
spec_path = f"{task['path']}/SPEC.md"
# Write SPEC.md with technical details

# 3. After spec review, start implementation
task_update(feature["task_id"], status="active")
worktree = task_worktree(feature["task_id"])

# 4. Implement in worktree
```

### Pattern: Searching Related Tasks

```python
# Find all tasks related to export functionality
export_tasks = task_list(tags=["export"])

# Find blocked tasks to unblock
blocked = task_list(status="blocked")

# Find tasks assigned to you
my_tasks = task_list(assigned_to="your-username", status="active")

# Find overdue tasks
# (manually filter by due_date after retrieving)
all_tasks = task_list(limit=100)
overdue = [t for t in all_tasks if t.get("due_date") and t["due_date"] < today]
```

## Status Workflow

Tasks follow this status progression:

```
pending → active → review → completed → archived
         ↘     ↗
          blocked
```

**Status meanings:**
- `pending`: Not started (default)
- `active`: Currently being worked on
- `blocked`: Waiting on dependencies/external factors
- `review`: Code complete, in PR review
- `completed`: Merged and done
- `archived`: Historical record

**Best practices:**
- Move to `active` when starting work
- Use `blocked` with README notes explaining blocker
- Move to `review` when PR is created
- Only mark `completed` after merge
- Archive old completed tasks periodically

## Tips for Effective Task Management

### DO:

✅ Call `task_worktree` before any code changes
✅ Update task status as work progresses
✅ Use tags for easy filtering and searching
✅ Create subtasks for complex epics
✅ Link dependencies between tasks
✅ Document blocking issues in README
✅ Use appropriate task types
✅ Keep task titles concise and descriptive

### DON'T:

❌ Edit YAML front matter directly (use MCP tools)
❌ Skip worktree creation before coding
❌ Mark tasks complete before PR merge
❌ Create overly broad task descriptions
❌ Forget to update status during workflow
❌ Work in main repo instead of worktree
❌ Leave tasks in `active` status indefinitely

## Project Management

### Listing Projects

```python
# Get all registered projects
projects = project_list()

# Get specific project details
project = project_get("TM")  # or project_get("taskmaster")
```

### Project Structure

Projects are defined in `~/tasks/PROJECTS.txt`:

```
CODE  PROJECT     GIT_URL
----  -------     -------
TM    taskmaster  github.com/mbailey/taskmaster
VM    voicemode   github.com/mbailey/voicemode
AG    agents      github.com/mbailey/agents
```

### Creating Projects

```python
project_create(
    code="NEW",
    name="new-project",
    git_url="github.com/user/new-project"
)
```

## Troubleshooting

### Can't find a task

```python
# Search by partial title
all_tasks = task_list(limit=100)
matches = [t for t in all_tasks if "keyword" in t["title"].lower()]

# Check all projects (not just current)
task_list(project=None)
```

### Worktree creation fails

- Verify project git_url is set correctly
- Check that the git repository is accessible
- Ensure you have permissions for the repo directory

### Task status not updating

- Use MCP tools, not direct file editing
- Check that task_id is correct (includes project code)
- Verify YAML syntax if manually edited

## Additional Resources

Load these reference files when needed for more details:

- **references/mcp-tools.md** - Complete MCP tool documentation with all parameters and examples
- **references/workflow.md** - Detailed software development workflow with git, commits, PRs
- **references/task-structure.md** - Task directory structure, README format, and templates

These references contain in-depth information and should be consulted when working on complex task operations or when you need detailed specifications.

## Quick Command Reference

```python
# Create task
task_create(project="TM", type="feat", title="New feature")

# List tasks
task_list(status="active")              # Active in current project
task_list(type="feat", priority="high")  # Filtered query
task_list(parent="TM-50")               # Subtasks of epic

# Update task
task_update(task_id="TM-65", status="active")
task_update(task_id="TM-65", priority="critical", tags=["urgent"])

# Get task
task = task_get("TM-65")

# Worktree (REQUIRED before code changes)
worktree = task_worktree("TM-65")

# Projects
projects = project_list()
project = project_get("TM")
```

## Summary

The taskmaster skill provides comprehensive task management with:

1. **Structured task creation** with metadata and templates
2. **Powerful search and filtering** to find relevant tasks
3. **Status tracking** through the complete workflow
4. **Git integration** via worktrees for isolated development
5. **Epic/subtask hierarchies** for complex initiatives
6. **MCP tools** for programmatic task management
7. **Project organization** with auto-detection

Always use Taskmaster MCP tools for task operations, follow the development workflow for code changes, and maintain task status throughout the work lifecycle.
